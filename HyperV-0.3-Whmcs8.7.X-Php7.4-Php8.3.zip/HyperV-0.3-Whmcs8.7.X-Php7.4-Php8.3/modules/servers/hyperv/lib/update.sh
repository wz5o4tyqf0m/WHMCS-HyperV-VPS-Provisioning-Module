#!/bin/bash

# Usage
# pwd should be 'whmcs_installation/modules/servers/hyperv/lib'
# sh update.sh

echo "hyperv Update Script"
echo "====================="

echo "Cloning repo"
git clone https://github.com/fintech-systems/hyperv-whmcs
echo "------------"

echo "Copying addons to WHMCS installation location..."
cp -r hyperv-whmcs/addons/hyperv/ ../../../addons/        
echo "------------------------------------------------"

echo "Copying servers to WHMCS installation location..."
cp -r hyperv-whmcs/servers/hyperv ../../../servers/ 
echo "-------------------------------------------------"

echo "Removing clone"
rm -rf hyperv-whmcs
echo "--------------"

echo "DONE"
